package change.code;

class Test_3 {
    int x;
    int y;

    Test_3(int x) {
        x = 10; 
    }

    void display() {
        System.out.println(x);
    }
}

