package change.code;


class F2 extends E2 {
    int x = 15;
    
   
   void  print() {
       System.out.println(x);   //  change this
   }
}

class E2 {
	 public static void main(String[] args) {
		   E2  obj =new E2();
		   
	   }
  private  int x = 5;
  
}



