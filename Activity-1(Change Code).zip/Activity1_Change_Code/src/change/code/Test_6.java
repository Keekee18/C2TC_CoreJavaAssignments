package change.code;

class Person {}


public class Test_6 {
    
      Student p = new Student();   
        System.out.println( );
    }
}
class Student extends Person {}
