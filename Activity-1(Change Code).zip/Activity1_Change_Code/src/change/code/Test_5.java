package change.code;

class A3 {
    void display() {
        System.out.println("A display");
       display();
    }
}

class B3 extends A3 {
        System.out.println("B display");

    
public static void main(String([] arg ){
    void show(); 
        display();  
    }
}

